export const Role = {
  Admin: 'ADMIN',
  User: 'USER',
};
