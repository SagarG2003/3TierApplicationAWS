import FormBlog from '@/components/form-blog';

const AddBlog = () => {
  return <FormBlog type="new" />;
};

export default AddBlog;
